# Initialize scoreboards and schedule the first spawn (every 12000 ticks = 10 minutes)
scoreboard objectives add rand dummy
scoreboard objectives add mobrand dummy
# Schedule the recurring spawn function (will reschedule itself each run).
schedule function more_passive_spawns:spawn_random 12000
