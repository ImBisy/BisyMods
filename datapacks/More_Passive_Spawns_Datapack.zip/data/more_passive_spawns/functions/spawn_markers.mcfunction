# Summon three invisible marker armor stands at the anchor (player) position
summon armor_stand ~ ~ ~ {Tags:["spawnmarker"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b}
summon armor_stand ~ ~ ~ {Tags:["spawnmarker"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b}
summon armor_stand ~ ~ ~ {Tags:["spawnmarker"],Marker:1b,Invisible:1b,NoGravity:1b,Invulnerable:1b,Silent:1b}
# Spread the markers randomly around the player (surface Y is chosen by spreadplayers)
execute positioned ~ ~ ~ run spreadplayers ~ ~ 5 50 false @e[tag=spawnmarker]
# Randomly pick one marker and give it a random 0/1 score; if 0, kill it (50% chance) so we spawn 2-3 mobs total
scoreboard players random @e[tag=spawnmarker,limit=1,sort=random] rand 0 1
execute as @e[tag=spawnmarker,limit=1,sort=random] if score @s rand matches 0 run kill @s
# For each remaining marker, spawn a random passive mob (and remove the marker)
execute as @e[tag=spawnmarker] at @s run function more_passive_spawns:spawn_mob
