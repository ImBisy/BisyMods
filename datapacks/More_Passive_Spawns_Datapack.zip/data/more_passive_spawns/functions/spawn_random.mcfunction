# Reschedule next run (so it repeats indefinitely every 12000 ticks)
schedule function more_passive_spawns:spawn_random 12000
# Run the spawn procedure in the Overworld only
execute in minecraft:overworld run function more_passive_spawns:spawn_at_anchor
