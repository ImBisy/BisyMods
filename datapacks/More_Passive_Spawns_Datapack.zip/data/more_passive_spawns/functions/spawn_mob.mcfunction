# Choose a random mob type (0..3) and summon the corresponding passive mob at the marker's position, then remove the marker
scoreboard players random @s mobrand 0 3
execute as @s if score @s mobrand matches 0 run summon minecraft:sheep ~ ~ ~
execute as @s if score @s mobrand matches 1 run summon minecraft:cow ~ ~ ~
execute as @s if score @s mobrand matches 2 run summon minecraft:pig ~ ~ ~
execute as @s if score @s mobrand matches 3 run summon minecraft:chicken ~ ~ ~
kill @s
