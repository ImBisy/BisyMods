# Pick a random player in the Overworld and run the marker spawner at their feet
execute as @r[type=player] at @s in minecraft:overworld run function more_passive_spawns:spawn_markers
